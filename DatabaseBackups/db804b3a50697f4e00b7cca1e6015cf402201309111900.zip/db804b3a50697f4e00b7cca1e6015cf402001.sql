
--Create database

USE [master]
GO
IF NOT EXISTS (SELECT [name] FROM sys.databases WHERE name = N'db804b3a50697f4e00b7cca1e6015cf402')
BEGIN
CREATE DATABASE [db804b3a50697f4e00b7cca1e6015cf402] COLLATE SQL_Latin1_General_CP1_CI_AS
END
GO
EXEC dbo.sp_dbcmptlevel @dbname=N'db804b3a50697f4e00b7cca1e6015cf402', @new_cmptlevel=100
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
BEGIN
	EXEC [db804b3a50697f4e00b7cca1e6015cf402].[dbo].[sp_fulltext_database] @action = 'enable'
END
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET ANSI_NULL_DEFAULT OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET ANSI_NULLS OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET ANSI_PADDING OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET ANSI_WARNINGS OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET ARITHABORT OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET AUTO_CLOSE OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET AUTO_CREATE_STATISTICS ON
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET AUTO_SHRINK OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET AUTO_UPDATE_STATISTICS ON
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET CURSOR_CLOSE_ON_COMMIT OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET CURSOR_DEFAULT GLOBAL
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET CONCAT_NULL_YIELDS_NULL OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET NUMERIC_ROUNDABORT OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET QUOTED_IDENTIFIER OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET RECURSIVE_TRIGGERS OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET DISABLE_BROKER
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET AUTO_UPDATE_STATISTICS_ASYNC OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET DATE_CORRELATION_OPTIMIZATION OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET TRUSTWORTHY OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET TRUSTWORTHY OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET ALLOW_SNAPSHOT_ISOLATION OFF
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET PARAMETERIZATION SIMPLE
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET READ_WRITE
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET RECOVERY SIMPLE
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET MULTI_USER
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET PAGE_VERIFY CHECKSUM
GO
ALTER DATABASE [db804b3a50697f4e00b7cca1e6015cf402] SET DB_CHAINING OFF
GO

USE [db804b3a50697f4e00b7cca1e6015cf402]
GO

--Create Users
USE [db804b3a50697f4e00b7cca1e6015cf402]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE [name] = N'dbo')
	CREATE USER [dbo] WITHOUT LOGIN WITH DEFAULT_SCHEMA = [dbo];
GO

--Create Roles
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'public' AND type = 'R')
	CREATE ROLE [public] AUTHORIZATION [dbo]
GO

--Database Schemas

USE [db804b3a50697f4e00b7cca1e6015cf402]
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'dbo')
EXEC sys.sp_executesql N'CREATE SCHEMA [dbo] AUTHORIZATION [dbo]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'HumanResources')
EXEC sys.sp_executesql N'CREATE SCHEMA [HumanResources] AUTHORIZATION [dbo]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'Person')
EXEC sys.sp_executesql N'CREATE SCHEMA [Person] AUTHORIZATION [dbo]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'Production')
EXEC sys.sp_executesql N'CREATE SCHEMA [Production] AUTHORIZATION [dbo]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'Purchasing')
EXEC sys.sp_executesql N'CREATE SCHEMA [Purchasing] AUTHORIZATION [dbo]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'Sales')
EXEC sys.sp_executesql N'CREATE SCHEMA [Sales] AUTHORIZATION [dbo]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'History')
EXEC sys.sp_executesql N'CREATE SCHEMA [History] AUTHORIZATION [dbo]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'Admin')
EXEC sys.sp_executesql N'CREATE SCHEMA [Admin] AUTHORIZATION [dbo]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'guest')
EXEC sys.sp_executesql N'CREATE SCHEMA [guest] AUTHORIZATION [guest]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'INFORMATION_SCHEMA')
EXEC sys.sp_executesql N'CREATE SCHEMA [INFORMATION_SCHEMA] AUTHORIZATION [INFORMATION_SCHEMA]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'sys')
EXEC sys.sp_executesql N'CREATE SCHEMA [sys] AUTHORIZATION [sys]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'db_owner')
EXEC sys.sp_executesql N'CREATE SCHEMA [db_owner] AUTHORIZATION [db_owner]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'db_accessadmin')
EXEC sys.sp_executesql N'CREATE SCHEMA [db_accessadmin] AUTHORIZATION [db_accessadmin]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'db_securityadmin')
EXEC sys.sp_executesql N'CREATE SCHEMA [db_securityadmin] AUTHORIZATION [db_securityadmin]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'db_ddladmin')
EXEC sys.sp_executesql N'CREATE SCHEMA [db_ddladmin] AUTHORIZATION [db_ddladmin]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'db_backupoperator')
EXEC sys.sp_executesql N'CREATE SCHEMA [db_backupoperator] AUTHORIZATION [db_backupoperator]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'db_datareader')
EXEC sys.sp_executesql N'CREATE SCHEMA [db_datareader] AUTHORIZATION [db_datareader]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'db_datawriter')
EXEC sys.sp_executesql N'CREATE SCHEMA [db_datawriter] AUTHORIZATION [db_datawriter]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'db_denydatareader')
EXEC sys.sp_executesql N'CREATE SCHEMA [db_denydatareader] AUTHORIZATION [db_denydatareader]'
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'db_denydatawriter')
EXEC sys.sp_executesql N'CREATE SCHEMA [db_denydatawriter] AUTHORIZATION [db_denydatawriter]'
GO

--Database Tables

USE [db804b3a50697f4e00b7cca1e6015cf402]
GO

--Create table and its columns
CREATE TABLE [Purchasing].[PurchaseOrderHeader] (
	[PurchaseOrderId] [int] NOT NULL IDENTITY (1, 1),
	[StatusId] [int] NULL,
	[EmployeeId] [int] NULL,
	[VendorId] [int] NULL,
	[ShipMethodId] [int] NULL,
	[OrderDate] [datetime] NULL,
	[ShipDate] [datetime] NULL,
	[SubTotal] [money] NULL,
	[VAT] [money] NULL,
	[Freight] [money] NULL,
	[TotalDue] [sys].[money],
	[InvoiceNumber] [int] NULL CONSTRAINT [DF_PurchaseOrderHeader_IsInvoiced] DEFAULT ((0)),
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_PurchaseOrderHeader_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Production].[RecipeIngredient] (
	[RecipeIngredientId] [int] NOT NULL IDENTITY (1, 1),
	[RecipeId] [int] NULL,
	[ProductId] [int] NULL,
	[QuantityPerPortion] [float] NULL,
	[Cost] [money] NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_RecipeIngredient_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Production].[Recipe] (
	[RecipeId] [int] NOT NULL IDENTITY (1, 1),
	[CategoryId] [int] NULL,
	[Name] [nvarchar](1000) NULL,
	[Description] [nvarchar](1000) NULL,
	[ValuePerPortion] [money] NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_Recipe_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Production].[Product] (
	[ProductId] [int] NOT NULL IDENTITY (1, 1),
	[UnitMeasureId] [int] NULL,
	[CategoryId] [int] NULL,
	[StoreId] [int] NULL,
	[Name] [nvarchar](1000) NULL,
	[Code] [nvarchar](1000) NULL,
	[UnitPrice] [money] NULL CONSTRAINT [DF_Table_1_CostStocktacke] DEFAULT ((0)),
	[UnitsInStock] [int] NULL CONSTRAINT [DF_xProduct_UnitsInStock] DEFAULT ((0)),
	[UnitsOnOrder] [int] NULL CONSTRAINT [DF_xProduct_UnitsOnOrder] DEFAULT ((0)),
	[ReorderLevel] [int] NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_xProduct_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Purchasing].[ProductVendor] (
	[ProductVendorId] [int] NOT NULL IDENTITY (1, 1),
	[ProductId] [int] NULL,
	[VendorId] [int] NULL,
	[UnitMeasureId] [int] NULL,
	[AverageLeadTime] [int] NULL,
	[StandardPrice] [money] NULL,
	[LastReceiptCost] [money] NULL,
	[LastReceiptDate] [datetime] NULL,
	[MinOrderQuantity] [int] NULL,
	[MaxOrderQuantity] [int] NULL,
	[OnOrderQuantity] [int] NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_ProductVendor_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Sales].[SalesOrderStatus] (
	[SalesOrderStatusId] [int] NOT NULL IDENTITY (1, 1),
	[Name] [nvarchar](1000) NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_SalesOrderStatus_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL,
	[IsVisible] [bit] NULL);
GO

--Create table and its columns
CREATE TABLE [Sales].[SalesOrderHeader] (
	[OrderID] [int] NOT NULL IDENTITY (1, 1),
	[CustomerID] [int] NULL,
	[EmployeeID] [int] NULL,
	[StatusId] [int] NULL,
	[AccountName] [nvarchar](1000) NULL,
	[OrderDate] [datetime] NULL,
	[RequiredDate] [datetime] NULL,
	[ShippedDate] [datetime] NULL,
	[ShipName] [nvarchar](1000) NULL,
	[ShipAddress] [nvarchar](1000) NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_Order_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Purchasing].[ShipMethod] (
	[ShipMethodId] [int] NOT NULL IDENTITY (1, 1),
	[Name] [nvarchar](1000) NULL,
	[ShipBase] [money] NULL,
	[ShipRate] [money] NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_ShipMethod_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [dbo].[__RecipiesDataBase] (
	[databaseName] [nvarchar](50) NULL);
GO

--Create table and its columns
CREATE TABLE [Sales].[SalesOrderDetail] (
	[SalesOrderDetailId] [int] NOT NULL IDENTITY (1, 1),
	[SalesOrderId] [int] NULL,
	[RecipeId] [int] NULL,
	[OrderQuantity] [int] NULL,
	[UnitPrice] [money] NULL,
	[UnitPriceDiscount] [float] NULL CONSTRAINT [DF_SalesOrderDetail_UnitPriceDiscount] DEFAULT ((0)),
	[LineTotal] [sys].[float],
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_OrderDetail_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [HumanResources].[EmployeeDepartment] (
	[EmployeeDepartmentId] [int] NOT NULL IDENTITY (1, 1),
	[EmployeeId] [int] NULL,
	[DepartmentId] [int] NULL,
	[ShiftId] [int] NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_EmployeeDepartment_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [HumanResources].[Department] (
	[DepartmentId] [int] NOT NULL IDENTITY (1, 1),
	[Name] [nvarchar](1000) NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_Department_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Production].[UnitMeasure] (
	[UnitMeasureId] [int] NOT NULL IDENTITY (1, 1),
	[Name] [nvarchar](1000) NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_xUnit_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Production].[ProductCategory] (
	[CategoryId] [int] NOT NULL IDENTITY (1, 1),
	[Name] [nvarchar](1000) NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_xCategory_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Purchasing].[Vendor] (
	[VendorId] [int] NOT NULL IDENTITY (1, 1),
	[AccountNumber] [nvarchar](1000) NULL,
	[Name] [nvarchar](1000) NULL,
	[Address] [nvarchar](1000) NULL,
	[Phone] [nvarchar](1000) NULL,
	[Fax] [nvarchar](1000) NULL,
	[Email] [nvarchar](1000) NULL,
	[HomePage] [nvarchar](1000) NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_xSupplier_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Production].[ProductHistory] (
	[ProductHistoryId] [int] NOT NULL IDENTITY (1, 1),
	[ProductId] [int] NULL,
	[UnitMeasureId] [int] NULL,
	[CategoryId] [int] NULL,
	[Name] [nvarchar](1000) NULL,
	[Code] [nvarchar](1000) NULL,
	[UnitPrice] [money] NULL,
	[UnitsInStock] [int] NULL,
	[UnitsOnOrder] [int] NULL,
	[Store] [nvarchar](1000) NULL,
	[ReorderLevel] [int] NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Production].[Store] (
	[StoreId] [int] NOT NULL IDENTITY (1, 1),
	[Name] [nvarchar](1000) NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_Store_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [HumanResources].[Shift] (
	[ShiftId] [int] NOT NULL IDENTITY (1, 1),
	[Name] [nvarchar](1000) NULL,
	[StartHour] [datetime] NULL,
	[EndHour] [datetime] NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_Shift_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Purchasing].[PurchaseOrderStatus] (
	[PurchaseOrderStatusId] [int] NOT NULL IDENTITY (1, 1),
	[Name] [nvarchar](1000) NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_PurchaseOrderStatus_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL,
	[IsVisible] [bit] NULL);
GO

--Create table and its columns
CREATE TABLE [Sales].[Customer] (
	[CustomerID] [int] NOT NULL IDENTITY (1, 1),
	[CompanyName] [nvarchar](1000) NULL,
	[ContactName] [nvarchar](1000) NULL,
	[Address] [nvarchar](1000) NULL,
	[Country] [nvarchar](1000) NULL,
	[Phone] [nvarchar](1000) NULL,
	[Email] [nvarchar](1000) NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_Customer_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Admin].[EmailTemplate] (
	[EmailTemplateId] [int] NOT NULL IDENTITY (1, 1),
	[From] [nvarchar](1000) NULL,
	[Cc] [nvarchar](1000) NULL,
	[Bcc] [nvarchar](1000) NULL,
	[Subject] [nvarchar](1000) NULL,
	[TextBody] [nvarchar](1000) NULL,
	[HtmlBody] [nvarchar](1000) NULL,
	[AttachmentName] [nvarchar](1000) NULL,
	[IsDefault] [bit] NOT NULL CONSTRAINT [DF_EmailTemplate_IsDefault] DEFAULT ((0)),
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_EmailTemplate_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [HumanResources].[Employee] (
	[EmployeeID] [int] NOT NULL IDENTITY (1, 1),
	[LastName] [nvarchar](1000) NULL,
	[FirstName] [nvarchar](1000) NULL,
	[BirthDate] [datetime] NULL,
	[HireDate] [datetime] NULL,
	[Address] [nvarchar](1000) NULL,
	[City] [nvarchar](1000) NULL,
	[Region] [nvarchar](1000) NULL,
	[PostalCode] [nvarchar](1000) NULL,
	[Country] [nvarchar](1000) NULL,
	[HomePhone] [nvarchar](1000) NULL,
	[PreviousExperience] [nvarchar](1000) NULL,
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_Employee_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

--Create table and its columns
CREATE TABLE [Purchasing].[PurchaseOrderDetail] (
	[PurchaseOrderDetailId] [int] NOT NULL IDENTITY (1, 1),
	[PurchaseOrderId] [int] NULL,
	[ProductId] [int] NULL,
	[OrderQuantity] [int] NULL,
	[UnitPrice] [money] NULL,
	[LineTotal] [sys].[money],
	[ReceivedQuantity] [int] NULL,
	[ReturnedQuantity] [int] NULL,
	[StockedQuantity] [sys].[int],
	[ModifiedDate] [datetime] NULL CONSTRAINT [DF_PurchaseOrderDetail_ModifiedDate] DEFAULT (getdate()),
	[ModifiedByUser] [nvarchar](1000) NULL);
GO

SET IDENTITY_INSERT [Purchasing].[PurchaseOrderHeader] ON
GO
INSERT INTO [Purchasing].[PurchaseOrderHeader] ([PurchaseOrderId], [StatusId], [EmployeeId], [VendorId], [ShipMethodId], [OrderDate], [ShipDate], [SubTotal], [VAT], [Freight], [InvoiceNumber], [ModifiedDate], [ModifiedByUser])
	VALUES (1, 2, 1, 3, 1, CAST(0x0000a20b00000000 AS datetime), CAST(0x0000a21b00000000 AS datetime), CAST ('2.0000' AS money), CAST ('-1.0000' AS money), CAST ('11.0000' AS money), 1214, CAST(0x0000a23500ba8b12 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderHeader] ([PurchaseOrderId], [StatusId], [EmployeeId], [VendorId], [ShipMethodId], [OrderDate], [ShipDate], [SubTotal], [VAT], [Freight], [InvoiceNumber], [ModifiedDate], [ModifiedByUser])
	VALUES (2, 2, 1, 3, 1, CAST(0x0000a21500000000 AS datetime), CAST(0x0000a22400000000 AS datetime), CAST ('2.0000' AS money), CAST ('12.0000' AS money), CAST ('2.0000' AS money), 0, CAST(0x0000a223018334de AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderHeader] ([PurchaseOrderId], [StatusId], [EmployeeId], [VendorId], [ShipMethodId], [OrderDate], [ShipDate], [SubTotal], [VAT], [Freight], [InvoiceNumber], [ModifiedDate], [ModifiedByUser])
	VALUES (3, 1, 1, 3, 1, CAST(0x0000a21b00000000 AS datetime), CAST(0x0000a22300000000 AS datetime), CAST ('123.0000' AS money), CAST ('12.0000' AS money), CAST ('123.0000' AS money), 1, CAST(0x0000a22a00a97913 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderHeader] ([PurchaseOrderId], [StatusId], [EmployeeId], [VendorId], [ShipMethodId], [OrderDate], [ShipDate], [SubTotal], [VAT], [Freight], [InvoiceNumber], [ModifiedDate], [ModifiedByUser])
	VALUES (4, 4, 1, 3, 1, CAST(0x0000a21b00000000 AS datetime), CAST(0x0000a22900000000 AS datetime), CAST ('66666.0000' AS money), CAST ('55555.0000' AS money), CAST ('4212.0000' AS money), 0, CAST(0x0000a22d00be66f4 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderHeader] ([PurchaseOrderId], [StatusId], [EmployeeId], [VendorId], [ShipMethodId], [OrderDate], [ShipDate], [SubTotal], [VAT], [Freight], [InvoiceNumber], [ModifiedDate], [ModifiedByUser])
	VALUES (5, 3, 1, 3, 1, CAST(0x0000a20b00000000 AS datetime), CAST(0x0000a23200000000 AS datetime), CAST ('34323.0000' AS money), CAST ('122.0000' AS money), CAST ('23.0000' AS money), 0, CAST(0x0000a22d01139ece AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderHeader] ([PurchaseOrderId], [StatusId], [EmployeeId], [VendorId], [ShipMethodId], [OrderDate], [ShipDate], [SubTotal], [VAT], [Freight], [InvoiceNumber], [ModifiedDate], [ModifiedByUser])
	VALUES (10, 1, 1, 3, 1, CAST(0x0000a22700000000 AS datetime), CAST(0x0000a23e00000000 AS datetime), CAST ('343234.0000' AS money), CAST ('4444.0000' AS money), CAST ('555.0000' AS money), 0, CAST(0x0000a22d009fc7e6 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderHeader] ([PurchaseOrderId], [StatusId], [EmployeeId], [VendorId], [ShipMethodId], [OrderDate], [ShipDate], [SubTotal], [VAT], [Freight], [InvoiceNumber], [ModifiedDate], [ModifiedByUser])
	VALUES (11, 1, 1, 3, 1, CAST(0x0000a22d00000000 AS datetime), CAST(0x0000a22e00000000 AS datetime), NULL, NULL, NULL, 1, CAST(0x0000a22d00a1b712 AS datetime), N'pavlina')

GO
INSERT INTO [Purchasing].[PurchaseOrderHeader] ([PurchaseOrderId], [StatusId], [EmployeeId], [VendorId], [ShipMethodId], [OrderDate], [ShipDate], [SubTotal], [VAT], [Freight], [InvoiceNumber], [ModifiedDate], [ModifiedByUser])
	VALUES (13, 1, 1, 3, 1, CAST(0x0000a22800000000 AS datetime), NULL, NULL, NULL, NULL, 4, CAST(0x0000a23401114f1d AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Purchasing].[PurchaseOrderHeader] OFF
GO

SET IDENTITY_INSERT [Production].[RecipeIngredient] ON
GO
INSERT INTO [Production].[RecipeIngredient] ([RecipeIngredientId], [RecipeId], [ProductId], [QuantityPerPortion], [Cost], [ModifiedDate], [ModifiedByUser])
	VALUES (6, 5, 1, CAST ('2' AS float), CAST ('11.0000' AS money), CAST(0x0000a233008bd718 AS datetime), N'admin')

GO
INSERT INTO [Production].[RecipeIngredient] ([RecipeIngredientId], [RecipeId], [ProductId], [QuantityPerPortion], [Cost], [ModifiedDate], [ModifiedByUser])
	VALUES (10, 3, 3, CAST ('2' AS float), CAST ('3.0000' AS money), CAST(0x0000a23100985d02 AS datetime), N'admin')

GO
INSERT INTO [Production].[RecipeIngredient] ([RecipeIngredientId], [RecipeId], [ProductId], [QuantityPerPortion], [Cost], [ModifiedDate], [ModifiedByUser])
	VALUES (12, 3, NULL, CAST ('8' AS float), CAST ('7.0000' AS money), CAST(0x0000a2310098c80c AS datetime), N'admin')

GO
INSERT INTO [Production].[RecipeIngredient] ([RecipeIngredientId], [RecipeId], [ProductId], [QuantityPerPortion], [Cost], [ModifiedDate], [ModifiedByUser])
	VALUES (13, 5, 5, CAST ('2' AS float), CAST ('333.0000' AS money), CAST(0x0000a231009ff8b2 AS datetime), N'admin')

GO
INSERT INTO [Production].[RecipeIngredient] ([RecipeIngredientId], [RecipeId], [ProductId], [QuantityPerPortion], [Cost], [ModifiedDate], [ModifiedByUser])
	VALUES (14, 6, 2, CAST ('2' AS float), CAST ('3.0000' AS money), CAST(0x0000a23100dc28c5 AS datetime), N'admin')

GO
INSERT INTO [Production].[RecipeIngredient] ([RecipeIngredientId], [RecipeId], [ProductId], [QuantityPerPortion], [Cost], [ModifiedDate], [ModifiedByUser])
	VALUES (16, 3, 1, CAST ('2' AS float), CAST ('1.0000' AS money), CAST(0x0000a23100ddcfd9 AS datetime), N'admin')

GO
INSERT INTO [Production].[RecipeIngredient] ([RecipeIngredientId], [RecipeId], [ProductId], [QuantityPerPortion], [Cost], [ModifiedDate], [ModifiedByUser])
	VALUES (17, 8, 1, CAST ('1' AS float), CAST ('1.0000' AS money), CAST(0x0000a23300ff1d2d AS datetime), N'admin')

GO
INSERT INTO [Production].[RecipeIngredient] ([RecipeIngredientId], [RecipeId], [ProductId], [QuantityPerPortion], [Cost], [ModifiedDate], [ModifiedByUser])
	VALUES (18, 9, 5, CAST ('0.1' AS float), CAST ('10.0000' AS money), CAST(0x0000a23301024715 AS datetime), N'pavlina')

GO
INSERT INTO [Production].[RecipeIngredient] ([RecipeIngredientId], [RecipeId], [ProductId], [QuantityPerPortion], [Cost], [ModifiedDate], [ModifiedByUser])
	VALUES (19, 3, 3, CAST ('111' AS float), CAST ('0.0000' AS money), CAST(0x0000a23600fb9f6a AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Production].[RecipeIngredient] OFF
GO

SET IDENTITY_INSERT [Production].[Recipe] ON
GO
INSERT INTO [Production].[Recipe] ([RecipeId], [CategoryId], [Name], [Description], [ValuePerPortion], [ModifiedDate], [ModifiedByUser])
	VALUES (3, 4, N'This is my first recipe1', N'<ol>
    <li>Mix the cream.</li>
    <li></li>
    <li>Mix cream and cheese together (on hand).</li>
    <li></li>
    <li>Put gelatin in water for 10 min until it is soft.</li>
    <li></li>
    <li>Put the gelatin in a little water on the ring, mix it with toffee sauce, add honey comb crunches and mix with cheese and cream.</li>
    <li></li>
    <li>Put the butter in a pan until it is milt add the brown sugar and&nbsp; honey and leave it on the ring for 1 min, after that add crushed biscuits and chill in the freezer for 5 min.</li>
    <li>Put the biscuits in a pan cake and add the cheese cream.</li>
    <li>Chill for 4-5 hours.</li>
</ol>
<p>&nbsp;</p>
<div><br />
</div>', CAST ('11.0000' AS money), CAST(0x0000a23400ca8f63 AS datetime), N'admin')

GO
INSERT INTO [Production].[Recipe] ([RecipeId], [CategoryId], [Name], [Description], [ValuePerPortion], [ModifiedDate], [ModifiedByUser])
	VALUES (5, 3, N'recipe 2', N'test111111', CAST ('344.0000' AS money), CAST(0x0000a23400bead33 AS datetime), N'admin')

GO
INSERT INTO [Production].[Recipe] ([RecipeId], [CategoryId], [Name], [Description], [ValuePerPortion], [ModifiedDate], [ModifiedByUser])
	VALUES (6, 4, N'1', N'test', CAST ('3.0000' AS money), CAST(0x0000a23100db412b AS datetime), N'admin')

GO
INSERT INTO [Production].[Recipe] ([RecipeId], [CategoryId], [Name], [Description], [ValuePerPortion], [ModifiedDate], [ModifiedByUser])
	VALUES (8, 4, N'yordan test', N'some description', CAST ('1.0000' AS money), CAST(0x0000a23300feb40a AS datetime), N'admin')

GO
INSERT INTO [Production].[Recipe] ([RecipeId], [CategoryId], [Name], [Description], [ValuePerPortion], [ModifiedDate], [ModifiedByUser])
	VALUES (9, 3, N'Cheese cake', N'<ol>
    <li><span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Mix the cream.</span></li>
    <li><span>Mix cream and cheese together (on hand).</span></li>
    <li><span>Put gelatin in water for 10 min until it is soft.</span></li>
    <li><span>Put the gelatin in a little water on the ring, mix it with toffee sauce, add honey comb crunches and mix with cheese and cream.</span></li>
    <li><span>Put the butter in a pan until it is milt add the brown sugar and&nbsp; honey and leave it on the ring for 1 min, after that add crushed biscuits and chill in the freezer for 5 min.</span></li>
    <li><span>Put the biscuits in a pan cake and add the cheese cream.</span></li>
    <li><span>Chill for 4-5 hours.</span></li>
</ol>
<p><span>&nbsp;</span></p>', CAST ('10.0000' AS money), CAST(0x0000a233017b256b AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Production].[Recipe] OFF
GO

SET IDENTITY_INSERT [Production].[Product] ON
GO
INSERT INTO [Production].[Product] ([ProductId], [UnitMeasureId], [CategoryId], [StoreId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (1, 3, 1, 1, N'Cherry', N'asdasdasd12345ssssssssss', CAST ('1.0000' AS money), 1219, 12, 12, CAST(0x0000a23600fc6a32 AS datetime), N'admin')

GO
INSERT INTO [Production].[Product] ([ProductId], [UnitMeasureId], [CategoryId], [StoreId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (2, 2, 1, 2, N'212', N'1', CAST ('2.0000' AS money), 211, 0, 5, CAST(0x0000a22f00fa09bc AS datetime), N'admin')

GO
INSERT INTO [Production].[Product] ([ProductId], [UnitMeasureId], [CategoryId], [StoreId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (3, 3, 1, 2, N'opps', N'test code', CAST ('0.0000' AS money), 12, 321, 12, CAST(0x0000a22f00fa2ea3 AS datetime), N'admin')

GO
INSERT INTO [Production].[Product] ([ProductId], [UnitMeasureId], [CategoryId], [StoreId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (5, 1, 3, NULL, N'Chocolate', NULL, CAST ('11.0000' AS money), -193, -12, 3, CAST(0x0000a23600fc6a32 AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Production].[Product] OFF
GO

SET IDENTITY_INSERT [Purchasing].[ProductVendor] ON
GO
INSERT INTO [Purchasing].[ProductVendor] ([ProductVendorId], [ProductId], [VendorId], [UnitMeasureId], [AverageLeadTime], [StandardPrice], [LastReceiptCost], [LastReceiptDate], [MinOrderQuantity], [MaxOrderQuantity], [OnOrderQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (1, 1, 3, 2, 12, CAST ('1.0000' AS money), CAST ('1.0000' AS money), CAST(0x0000a21300000000 AS datetime), 2, 32, 12, CAST(0x0000a2230165f96f AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[ProductVendor] ([ProductVendorId], [ProductId], [VendorId], [UnitMeasureId], [AverageLeadTime], [StandardPrice], [LastReceiptCost], [LastReceiptDate], [MinOrderQuantity], [MaxOrderQuantity], [OnOrderQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (2, 5, 3, 3, 12, CAST ('2.0000' AS money), CAST ('2.0000' AS money), CAST(0x0000a21b00000000 AS datetime), 4, 31, NULL, CAST(0x0000a222009c9c82 AS datetime), NULL)

GO
SET IDENTITY_INSERT [Purchasing].[ProductVendor] OFF
GO

SET IDENTITY_INSERT [Sales].[SalesOrderStatus] ON
GO
INSERT INTO [Sales].[SalesOrderStatus] ([SalesOrderStatusId], [Name], [ModifiedDate], [ModifiedByUser], [IsVisible])
	VALUES (1, N'In process', CAST(0x0000a23000bf536e AS datetime), NULL, CAST ('False' AS bit))

GO
INSERT INTO [Sales].[SalesOrderStatus] ([SalesOrderStatusId], [Name], [ModifiedDate], [ModifiedByUser], [IsVisible])
	VALUES (2, N'Approved', CAST(0x0000a23000bf63c2 AS datetime), NULL, CAST ('True' AS bit))

GO
INSERT INTO [Sales].[SalesOrderStatus] ([SalesOrderStatusId], [Name], [ModifiedDate], [ModifiedByUser], [IsVisible])
	VALUES (3, N'Backordered', CAST(0x0000a23000bf6dc1 AS datetime), NULL, CAST ('False' AS bit))

GO
INSERT INTO [Sales].[SalesOrderStatus] ([SalesOrderStatusId], [Name], [ModifiedDate], [ModifiedByUser], [IsVisible])
	VALUES (4, N'Rejected', CAST(0x0000a23000bf77dd AS datetime), NULL, CAST ('False' AS bit))

GO
INSERT INTO [Sales].[SalesOrderStatus] ([SalesOrderStatusId], [Name], [ModifiedDate], [ModifiedByUser], [IsVisible])
	VALUES (5, N'Shipped', CAST(0x0000a23000bf8776 AS datetime), NULL, CAST ('False' AS bit))

GO
INSERT INTO [Sales].[SalesOrderStatus] ([SalesOrderStatusId], [Name], [ModifiedDate], [ModifiedByUser], [IsVisible])
	VALUES (6, N'Cancelled', CAST(0x0000a23000bf935c AS datetime), NULL, CAST ('True' AS bit))

GO
SET IDENTITY_INSERT [Sales].[SalesOrderStatus] OFF
GO

SET IDENTITY_INSERT [Sales].[SalesOrderHeader] ON
GO
INSERT INTO [Sales].[SalesOrderHeader] ([OrderID], [CustomerID], [EmployeeID], [StatusId], [AccountName], [OrderDate], [RequiredDate], [ShippedDate], [ShipName], [ShipAddress], [ModifiedDate], [ModifiedByUser])
	VALUES (2, 1, 1, 6, N'456', CAST(0x0000a22400000000 AS datetime), CAST(0x0000a21300000000 AS datetime), CAST(0x0000a22300000000 AS datetime), N'sdf', N'sdf', CAST(0x0000a23600fc573a AS datetime), N'admin')

GO
INSERT INTO [Sales].[SalesOrderHeader] ([OrderID], [CustomerID], [EmployeeID], [StatusId], [AccountName], [OrderDate], [RequiredDate], [ShippedDate], [ShipName], [ShipAddress], [ModifiedDate], [ModifiedByUser])
	VALUES (3, 1, 1, 2, N'12', CAST(0x0000a23000000000 AS datetime), CAST(0x0000a22f00000000 AS datetime), CAST(0x0000a23800000000 AS datetime), N'1', N'2', CAST(0x0000a2330102cb58 AS datetime), N'admin')

GO
INSERT INTO [Sales].[SalesOrderHeader] ([OrderID], [CustomerID], [EmployeeID], [StatusId], [AccountName], [OrderDate], [RequiredDate], [ShippedDate], [ShipName], [ShipAddress], [ModifiedDate], [ModifiedByUser])
	VALUES (4, 1, 1, 6, NULL, CAST(0x0000a23300000000 AS datetime), NULL, NULL, NULL, NULL, CAST(0x0000a23600fc6b14 AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Sales].[SalesOrderHeader] OFF
GO

SET IDENTITY_INSERT [Purchasing].[ShipMethod] ON
GO
INSERT INTO [Purchasing].[ShipMethod] ([ShipMethodId], [Name], [ShipBase], [ShipRate], [ModifiedDate], [ModifiedByUser])
	VALUES (1, N'ZY - EXPRESS', CAST ('2.0000' AS money), CAST ('12.3400' AS money), CAST(0x0000a2210129ded4 AS datetime), NULL)

GO
SET IDENTITY_INSERT [Purchasing].[ShipMethod] OFF
GO

SET IDENTITY_INSERT [Sales].[SalesOrderDetail] ON
GO
INSERT INTO [Sales].[SalesOrderDetail] ([SalesOrderDetailId], [SalesOrderId], [RecipeId], [OrderQuantity], [UnitPrice], [UnitPriceDiscount], [ModifiedDate], [ModifiedByUser])
	VALUES (2, 2, 5, 2, CAST ('1.0000' AS money), CAST ('0.2' AS float), CAST(0x0000a23300c94169 AS datetime), N'admin')

GO
INSERT INTO [Sales].[SalesOrderDetail] ([SalesOrderDetailId], [SalesOrderId], [RecipeId], [OrderQuantity], [UnitPrice], [UnitPriceDiscount], [ModifiedDate], [ModifiedByUser])
	VALUES (3, 2, 5, 2, CAST ('1.0000' AS money), CAST ('0.12' AS float), CAST(0x0000a23400dc1aaf AS datetime), N'admin')

GO
INSERT INTO [Sales].[SalesOrderDetail] ([SalesOrderDetailId], [SalesOrderId], [RecipeId], [OrderQuantity], [UnitPrice], [UnitPriceDiscount], [ModifiedDate], [ModifiedByUser])
	VALUES (4, 4, 9, 10, CAST ('15.0000' AS money), CAST ('0' AS float), CAST(0x0000a2330103c6aa AS datetime), N'admin')

GO
INSERT INTO [Sales].[SalesOrderDetail] ([SalesOrderDetailId], [SalesOrderId], [RecipeId], [OrderQuantity], [UnitPrice], [UnitPriceDiscount], [ModifiedDate], [ModifiedByUser])
	VALUES (5, 4, 5, 30, CAST ('3.0000' AS money), CAST ('0.1' AS float), CAST(0x0000a2330104566d AS datetime), N'pavlina')

GO
INSERT INTO [Sales].[SalesOrderDetail] ([SalesOrderDetailId], [SalesOrderId], [RecipeId], [OrderQuantity], [UnitPrice], [UnitPriceDiscount], [ModifiedDate], [ModifiedByUser])
	VALUES (6, 4, 8, 2, CAST ('2.0000' AS money), NULL, CAST(0x0000a2330103d4c7 AS datetime), N'admin')

GO
INSERT INTO [Sales].[SalesOrderDetail] ([SalesOrderDetailId], [SalesOrderId], [RecipeId], [OrderQuantity], [UnitPrice], [UnitPriceDiscount], [ModifiedDate], [ModifiedByUser])
	VALUES (7, 4, 5, 30, CAST ('5.0000' AS money), CAST ('0.1' AS float), CAST(0x0000a23301042b10 AS datetime), N'pavlina')

GO
INSERT INTO [Sales].[SalesOrderDetail] ([SalesOrderDetailId], [SalesOrderId], [RecipeId], [OrderQuantity], [UnitPrice], [UnitPriceDiscount], [ModifiedDate], [ModifiedByUser])
	VALUES (8, 4, 9, 5, CAST ('10.0000' AS money), CAST ('0.1' AS float), CAST(0x0000a23301043df2 AS datetime), N'admin')

GO
INSERT INTO [Sales].[SalesOrderDetail] ([SalesOrderDetailId], [SalesOrderId], [RecipeId], [OrderQuantity], [UnitPrice], [UnitPriceDiscount], [ModifiedDate], [ModifiedByUser])
	VALUES (9, 4, 8, 1, CAST ('2.0000' AS money), NULL, CAST(0x0000a2330106df03 AS datetime), N'admin')

GO
INSERT INTO [Sales].[SalesOrderDetail] ([SalesOrderDetailId], [SalesOrderId], [RecipeId], [OrderQuantity], [UnitPrice], [UnitPriceDiscount], [ModifiedDate], [ModifiedByUser])
	VALUES (10, 2, 9, 1, CAST ('2.0000' AS money), CAST ('0.76' AS float), CAST(0x0000a23400dac975 AS datetime), N'admin')

GO
INSERT INTO [Sales].[SalesOrderDetail] ([SalesOrderDetailId], [SalesOrderId], [RecipeId], [OrderQuantity], [UnitPrice], [UnitPriceDiscount], [ModifiedDate], [ModifiedByUser])
	VALUES (11, 3, 3, 1, CAST ('2.0000' AS money), CAST ('0' AS float), CAST(0x0000a2340126f5c9 AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Sales].[SalesOrderDetail] OFF
GO

SET IDENTITY_INSERT [HumanResources].[EmployeeDepartment] ON
GO
INSERT INTO [HumanResources].[EmployeeDepartment] ([EmployeeDepartmentId], [EmployeeId], [DepartmentId], [ShiftId], [StartDate], [EndDate], [ModifiedDate], [ModifiedByUser])
	VALUES (1, 1, 1, 1, CAST(0x0000a20d00000000 AS datetime), CAST(0x0000a3de00000000 AS datetime), CAST(0x0000a222016bb313 AS datetime), N'admin')

GO
INSERT INTO [HumanResources].[EmployeeDepartment] ([EmployeeDepartmentId], [EmployeeId], [DepartmentId], [ShiftId], [StartDate], [EndDate], [ModifiedDate], [ModifiedByUser])
	VALUES (3, 1, 2, 1, CAST(0x0000a21100000000 AS datetime), CAST(0x0000a22900000000 AS datetime), CAST(0x0000a22201659b5a AS datetime), N'admin')

GO
SET IDENTITY_INSERT [HumanResources].[EmployeeDepartment] OFF
GO

SET IDENTITY_INSERT [HumanResources].[Department] ON
GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (1, N'Engineering', CAST(0x0000a22201131b50 AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (2, N'Tool Design', CAST(0x0000a22201131d11 AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (3, N'Sales', CAST(0x0000a22201131ec4 AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (4, N'Marketing', CAST(0x0000a22201132077 AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (5, N'Purchasing', CAST(0x0000a2220113220f AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (6, N'Research and Development', CAST(0x0000a222011323bd AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (7, N'Production', CAST(0x0000a22201132562 AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (8, N'Production Control', CAST(0x0000a22201132708 AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (9, N'Human Resources', CAST(0x0000a222011328e5 AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (10, N'Finance', CAST(0x0000a22201132a8a AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (11, N'Information Services', CAST(0x0000a22201132c39 AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (12, N'Document Control', CAST(0x0000a22201132de7 AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (13, N'Quality Assurance', CAST(0x0000a22201132f91 AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (14, N'Facilities and Maintenance', CAST(0x0000a2220113313b AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (15, N'Shipping and Receiving', CAST(0x0000a222011332e5 AS datetime), NULL)

GO
INSERT INTO [HumanResources].[Department] ([DepartmentId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (16, N'Executive', CAST(0x0000a2220113348f AS datetime), NULL)

GO
SET IDENTITY_INSERT [HumanResources].[Department] OFF
GO

SET IDENTITY_INSERT [Production].[UnitMeasure] ON
GO
INSERT INTO [Production].[UnitMeasure] ([UnitMeasureId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (1, N'Boxes', CAST(0x0000a27600c49d34 AS datetime), NULL)

GO
INSERT INTO [Production].[UnitMeasure] ([UnitMeasureId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (2, N'Bottle', CAST(0x0000a1fb00c4b1e9 AS datetime), NULL)

GO
INSERT INTO [Production].[UnitMeasure] ([UnitMeasureId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (3, N'Celsius', CAST(0x0000a1fb00c4b4a4 AS datetime), NULL)

GO
INSERT INTO [Production].[UnitMeasure] ([UnitMeasureId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (4, N'Canister', CAST(0x0000a1fb00c4fd78 AS datetime), NULL)

GO
INSERT INTO [Production].[UnitMeasure] ([UnitMeasureId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (5, N'Carton', CAST(0x0000a1fb00c50328 AS datetime), NULL)

GO
SET IDENTITY_INSERT [Production].[UnitMeasure] OFF
GO

SET IDENTITY_INSERT [Production].[ProductCategory] ON
GO
INSERT INTO [Production].[ProductCategory] ([CategoryId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (1, N'test ca1', CAST(0x0000a21e018a285e AS datetime), NULL)

GO
INSERT INTO [Production].[ProductCategory] ([CategoryId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (2, N'64w52', CAST(0x0000a04500000000 AS datetime), NULL)

GO
INSERT INTO [Production].[ProductCategory] ([CategoryId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (3, N'Milky', CAST(0x0000a21e0189abe4 AS datetime), NULL)

GO
INSERT INTO [Production].[ProductCategory] ([CategoryId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (4, N'Beeverages', CAST(0x0000a22d010e8bbb AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Production].[ProductCategory] OFF
GO

SET IDENTITY_INSERT [Purchasing].[Vendor] ON
GO
INSERT INTO [Purchasing].[Vendor] ([VendorId], [AccountNumber], [Name], [Address], [Phone], [Fax], [Email], [HomePage], [ModifiedDate], [ModifiedByUser])
	VALUES (3, N'Shell', N'John Smith', N'sd', N'a', N'sd12', N'ytodorov@ytodorov.com', N'http://recipies.apphb.com/', CAST(0x0000a23500835380 AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Purchasing].[Vendor] OFF
GO

SET IDENTITY_INSERT [Production].[ProductHistory] ON
GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (4, 3, 4, 3, N'1', N'test code', CAST ('0.0000' AS money), 0, 0, NULL, NULL, CAST(0x0000a22100db94af AS datetime), NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (5, 3, 3, 1, N'this is new name', N'test code', CAST ('0.0000' AS money), 12, 32, NULL, NULL, CAST(0x0000a22100dbc604 AS datetime), NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (6, NULL, 3, 3, N'test for inserts', N'2fsda', CAST ('12.0000' AS money), 22, 12, N'21', 21, CAST(0x0000a22100dd7b18 AS datetime), NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (7, 1, NULL, 1, N'Salmond', N'222ddd1', CAST ('12.0000' AS money), 1, 31, N'32dd', 45, CAST(0x0000a222012d2513 AS datetime), NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (8, 2, 2, 1, N'2', N'1', CAST ('2.0000' AS money), 2, 0, N'1', 5, CAST(0x0000a222012d992a AS datetime), NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (9, 1, NULL, 1, N'Salmond', N'222ddd1', CAST ('12.0000' AS money), 1, 12, N'32dd', 45, CAST(0x0000a22201358860 AS datetime), NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (10, 1, NULL, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), 1, 12, N'32dd', 45, CAST(0x0000a2220136a9d2 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (11, 6, 5, 1, N'Baloon', NULL, CAST ('4.4000' AS money), 4, 4, N'333', 55, CAST(0x0000a2220136b66f AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (12, NULL, 1, 2, N'test for inserts', NULL, NULL, NULL, NULL, NULL, NULL, CAST(0x0000a222016dc0e4 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (13, 7, 2, 1, N'Baloon', N'2', CAST ('4.4000' AS money), 4, 4, N'3331', 55, CAST(0x0000a223017d7ea0 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (14, 5, 1, 3, N'Chocolate', NULL, CAST ('1.0000' AS money), 3, 3, N'3', 3, CAST(0x0000a2230153b24c AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (15, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), 1, 12, N'32dd', 45, CAST(0x0000a2270165be23 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (16, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), 41, 12, N'32dd', 45, CAST(0x0000a22a00a97913 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (17, 5, 1, 3, N'Chocolate', NULL, CAST ('1.0000' AS money), 4, -246, N'3', 3, CAST(0x0000a22b013757d3 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (18, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), 47, 10, N'32dd', 45, CAST(0x0000a22b013757d7 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (19, 5, 1, 3, N'Chocolate', NULL, CAST ('1.0000' AS money), 4, 3, N'3', 3, CAST(0x0000a22b0137838a AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (20, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), 47, 12, N'32dd', 45, CAST(0x0000a22b0137838a AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (21, 5, 1, 3, N'Chocolate', NULL, CAST ('1.0000' AS money), -94, -246, N'3', 3, CAST(0x0000a22c0123feb2 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (22, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), -953, 10, N'32dd', 45, CAST(0x0000a22c0123feb9 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (23, 5, 1, 3, N'Chocolate', NULL, CAST ('1.0000' AS money), 4, 3, N'3', 3, CAST(0x0000a22c00ff906e AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (24, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), 47, 12, N'32dd', 45, CAST(0x0000a22c00ff9073 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (25, 5, 1, 3, N'Chocolate', NULL, CAST ('1.0000' AS money), -94, -246, N'3', 3, CAST(0x0000a22c00ffb4d0 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (26, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), -953, 10, N'32dd', 45, CAST(0x0000a22c00ffb4d0 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (27, 5, 1, 3, N'Chocolate', NULL, CAST ('1.0000' AS money), 4, 3, N'3', 3, CAST(0x0000a22c00ffec5e AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (28, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), 47, 12, N'32dd', 45, CAST(0x0000a22c00ffec5e AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (29, 5, 1, 3, N'Chocolate', NULL, CAST ('1.0000' AS money), -94, -246, N'3', 3, CAST(0x0000a22d00af7d8e AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (30, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), -953, 10, N'32dd', 45, CAST(0x0000a22d00af7d90 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (31, 5, 1, 3, N'Chocolate', NULL, CAST ('1.0000' AS money), -192, -246, N'3', 3, CAST(0x0000a22d00bd4dbf AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (32, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), -1953, 10, N'32dd', 45, CAST(0x0000a22d00bd4dce AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (33, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), 123, 10, N'32dd', 21, CAST(0x0000a22d010e3a8a AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (34, 3, 3, 1, N'this is new name', N'test code', CAST ('0.0000' AS money), 12, 32, NULL, 12, CAST(0x0000a22d010fab24 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (35, 5, 1, 3, N'Chocolate', NULL, CAST ('1.0000' AS money), -192, 3, N'3', 3, CAST(0x0000a22d010ff2aa AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (36, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), 123, 22, N'32dd', 21, CAST(0x0000a22d010ff2aa AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (37, 5, 1, 3, N'Chocolate', NULL, CAST ('1.0000' AS money), -189, -246, N'3', 3, CAST(0x0000a22d011065c5 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (38, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), -877, 10, N'32dd', 21, CAST(0x0000a22d011065c5 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (39, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), -877, 10, NULL, 21, CAST(0x0000a22e00bcb64f AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (40, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('123.0000' AS money), -877, 10, NULL, 21, CAST(0x0000a22e00bd4326 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (41, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('1231.0000' AS money), -877, 10, NULL, 21, CAST(0x0000a22f00ab0c6f AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (42, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('1231.0000' AS money), -877, 10111, NULL, 21, CAST(0x0000a22f00cf21e1 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (43, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('1231.0000' AS money), -877, 10111, NULL, 211, CAST(0x0000a22f00cfcfc0 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (44, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('1231.0000' AS money), -877, 10111, NULL, 2112, CAST(0x0000a22f00d0542d AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (45, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('1231.0000' AS money), -877, 10111, NULL, 21121, CAST(0x0000a22f00d067d4 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (46, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('1231.0000' AS money), -877, 10111, NULL, 211212, CAST(0x0000a22f00d0a1c1 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (47, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('1231.0000' AS money), -877, 101111, NULL, 211212, CAST(0x0000a22f00d10714 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (48, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('1231.0000' AS money), -87711, 101111, NULL, 211212, CAST(0x0000a22f00d12314 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (49, 1, 3, 1, N'Salmond', N'222ddd1', CAST ('1231.0000' AS money), -87711, 1111, NULL, 211212, CAST(0x0000a22f00d16243 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (50, 1, 2, 1, N'Salmond', N'222ddd1', CAST ('1231.0000' AS money), -87711, 1111, NULL, 211212, CAST(0x0000a22f00d31205 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (51, 1, 2, 1, N'Salmond', N'1', CAST ('1231.0000' AS money), -87711, 1111, NULL, 211212, CAST(0x0000a22f00d32b6d AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (52, 1, 5, 1, N'Salmond', N'1', CAST ('1231.0000' AS money), -87711, 1111, NULL, 211212, CAST(0x0000a22f00d38639 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (53, 1, 5, 1, N'Salmond7', N'1', CAST ('1231.0000' AS money), -87711, 1111, NULL, 211212, CAST(0x0000a22f00d3c875 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (54, 1, 5, 1, N'Salmond7', N'12', CAST ('1231.0000' AS money), -87711, 1111, NULL, 211212, CAST(0x0000a22f00d459ec AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (55, 1, 5, 1, N'Salmond7', N'12', CAST ('1231.0000' AS money), 12, 1111, NULL, 211212, CAST(0x0000a22f00d4c93f AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (56, 1, 5, 1, N'Salmond7', N'12', CAST ('1231.0000' AS money), 122, 1111, NULL, 211212, CAST(0x0000a22f00d7b11f AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (57, 1, 5, 1, N'Salmond7', N'12', CAST ('1231.0000' AS money), 1221, 1111, NULL, 211212, CAST(0x0000a22f00e6026a AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (58, 1, 5, 1, N'Salmond7', N'12', CAST ('1231.0000' AS money), 1221, 11112, NULL, 211212, CAST(0x0000a22f00e73e73 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (59, 1, 5, 1, N'Salmond72', N'12', CAST ('1231.0000' AS money), 1221, 11112, NULL, 211212, CAST(0x0000a22f00e8e64d AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (60, 1, 2, 1, N'Salmond72', N'12', CAST ('1231.0000' AS money), 1221, 11112, NULL, 211212, CAST(0x0000a22f00ea859d AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (61, 1, 2, 1, N'Salmond72', N'12', CAST ('1231.0000' AS money), 1221, 11112, NULL, 1, CAST(0x0000a22f00eab9fb AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (62, 1, 2, 1, N'Salmond722', N'12', CAST ('1231.0000' AS money), 1221, 11112, NULL, 1, CAST(0x0000a22f00ec5192 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (63, 1, 2, 1, N'Salmond7221', N'12', CAST ('1231.0000' AS money), 1221, 11112, NULL, 1, CAST(0x0000a22f00ed083e AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (64, 1, 2, 1, N'Salmond7221', N'12', CAST ('1231.0000' AS money), 1221, 11112111, NULL, 1, CAST(0x0000a22f00ed475d AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (65, 2, 2, 1, N'212', N'1', CAST ('2.0000' AS money), 2, 0, NULL, 5, CAST(0x0000a22f00ed6edf AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (66, 3, 3, 1, N'this is new name', N'test code', CAST ('0.0000' AS money), 12, 32, NULL, 12, CAST(0x0000a22f00ed894c AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (67, 1, 2, 1, N'Salmond2', N'12', CAST ('1231.0000' AS money), 1221, 11112111, NULL, 1, CAST(0x0000a22f00f038fd AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (68, 3, 3, 1, N'this is new name', N'test code', CAST ('0.0000' AS money), 12, 321, NULL, 12, CAST(0x0000a22f00f1a654 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (69, 1, 2, 1, N'Salmond2', N'12', CAST ('1.0000' AS money), 1221, 11112111, NULL, 1, CAST(0x0000a22f00f22256 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (70, 1, 2, 1, N'Salmond2', N'12', CAST ('1.0000' AS money), 1221, 11112111, NULL, 12, CAST(0x0000a22f00f23cec AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (71, 1, 2, 1, N'Salmond2', N'11', CAST ('1.0000' AS money), 1221, 11112111, NULL, 12, CAST(0x0000a22f00f24930 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (72, 1, 2, 1, N'Salmond2', N'asdasdasd', CAST ('1.0000' AS money), 1221, 11112111, NULL, 12, CAST(0x0000a22f00f25f39 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (73, 1, 2, 1, N'Salmond2', N'asdasdasd', CAST ('1.0000' AS money), 1221, 11112111, NULL, 12, CAST(0x0000a22f00f29565 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (74, 2, 2, 1, N'212', N'1', CAST ('2.0000' AS money), 211, 0, NULL, 5, CAST(0x0000a22f00f29f22 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (75, 2, 2, 1, N'212', N'1', CAST ('2.0000' AS money), 211, 0, NULL, 5, CAST(0x0000a22f00fa09bc AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (76, 3, 3, 1, N'opps', N'test code', CAST ('0.0000' AS money), 12, 321, NULL, 12, CAST(0x0000a22f00fa2ea3 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (77, 1, 2, 1, N'Salmond2', N'asdasdasd', CAST ('1.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a22f0116262a AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (78, 1, 2, 1, N'Salmond2', N'asdasdasd', CAST ('1.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a22f011754ed AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (79, 1, 2, 1, N'Cherry', N'asdasdasd', CAST ('1.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a22f01179923 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (80, 1, 4, 1, N'Cherry', N'asdasdasd', CAST ('1.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a230000a7a91 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (81, 1, 3, 1, N'Cherry', N'asdasdasd', CAST ('1.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a230000b5e21 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (82, 1, 4, 1, N'Cherry', N'asdasdasd', CAST ('1.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a230000c0261 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (83, 1, 4, 1, N'Cherry', N'asdasdasd', CAST ('222.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a230000d7102 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (84, 1, 1, 1, N'Cherry', N'asdasdasd', CAST ('222.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a230000ec930 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (85, 1, 5, 1, N'Cherry', N'asdasdasd', CAST ('222.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a2300015b65b AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (86, 5, 1, 3, N'Chocolate', NULL, CAST ('11.0000' AS money), -189, -246, NULL, 3, CAST(0x0000a2300015dda6 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (87, 1, 4, 1, N'Cherry', N'asdasdasd', CAST ('222.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a23000174ddd AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (88, 1, 3, 1, N'Cherry', N'asdasdasd', CAST ('222.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a2300018471b AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (89, 1, 3, 1, N'Cherry', N'asdasdasd', CAST ('222.0000' AS money), 1221, 1, NULL, 12, CAST(0x0000a23000bfa39c AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (90, 1, 3, 1, N'Cherry', N'asdasdasd', CAST ('222.0000' AS money), 1221, 1, NULL, 4, CAST(0x0000a23000c05ef6 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (91, 1, 3, 1, N'Cherry', N'asdasdasd', CAST ('222.0000' AS money), 1221, 1, NULL, 4, CAST(0x0000a23000cde891 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (92, 1, 3, 1, N'Cherry', N'asdasdasd', CAST ('222.0000' AS money), 1221, 12, NULL, 4, CAST(0x0000a230010de403 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (93, 1, 3, 1, N'Cherry', N'asdasdasd', CAST ('23.0000' AS money), 1221, 12, NULL, 4, CAST(0x0000a231010313b6 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (94, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (95, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (97, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (98, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (99, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (100, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (101, 0, NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, CAST(0x0000a23300e306da AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (102, 0, NULL, NULL, N'2', N'3', CAST ('2.0000' AS money), NULL, NULL, NULL, NULL, CAST(0x0000a23300e48f56 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (103, 15, NULL, NULL, N'2', N'3', CAST ('2.0000' AS money), 0, 0, NULL, NULL, CAST(0x0000a23300e48f56 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (104, 14, NULL, NULL, N'1', NULL, CAST ('0.0000' AS money), 0, 0, NULL, NULL, CAST(0x0000a23300e306da AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (105, 0, NULL, 2, N'22', N'22', NULL, NULL, NULL, NULL, NULL, CAST(0x0000a23300ea0e4c AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (106, 16, NULL, 2, N'22', N'22', CAST ('0.0000' AS money), 0, 0, NULL, NULL, CAST(0x0000a23300ea0e4c AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (107, 0, NULL, NULL, N'222', NULL, NULL, NULL, NULL, NULL, NULL, CAST(0x0000a23300ea64ef AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (108, 17, NULL, NULL, N'222', NULL, CAST ('0.0000' AS money), 0, 0, NULL, NULL, CAST(0x0000a23300ea64ef AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (109, 13, 2, 2, N'1', N'2fsda3', CAST ('4.0000' AS money), 4, 5556, NULL, 5, CAST(0x0000a23300e03da2 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (110, 12, 1, 2, N'22', N'22', CAST ('22.0000' AS money), 3, 33, NULL, 3, CAST(0x0000a23300dfca7a AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (111, 11, 1, 4, N'2', N'3', CAST ('4.0000' AS money), 5, 4, NULL, 3, CAST(0x0000a23300dcee53 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (112, 0, NULL, NULL, N'111', N'11', CAST ('11.0000' AS money), NULL, 111, NULL, NULL, CAST(0x0000a233011d090c AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (113, 18, NULL, NULL, N'11122', N'11', CAST ('11.0000' AS money), 0, 111, NULL, NULL, CAST(0x0000a233011d1489 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (114, 18, NULL, NULL, N'11122', N'11', CAST ('11.0000' AS money), 0, 111, NULL, NULL, CAST(0x0000a233011d1489 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (115, 0, NULL, NULL, N'1111111', NULL, NULL, NULL, NULL, NULL, NULL, CAST(0x0000a233011da2b3 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (116, 19, NULL, NULL, N'1111111', NULL, CAST ('0.0000' AS money), 0, 0, NULL, NULL, CAST(0x0000a233011da2b3 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (117, 0, NULL, NULL, N'3333', NULL, NULL, NULL, NULL, NULL, NULL, CAST(0x0000a233011deea4 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (118, 20, NULL, NULL, N'3333', NULL, CAST ('0.0000' AS money), 0, 0, NULL, NULL, CAST(0x0000a233011deea4 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (119, 10, 3, 3, N'test for inserts', N'2fsda', CAST ('12.0000' AS money), 22, 12, NULL, 21, CAST(0x0000a22100dd7b18 AS datetime), NULL)

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (120, 0, NULL, NULL, N'1', N'1', CAST ('1.0000' AS money), NULL, NULL, NULL, NULL, CAST(0x0000a233011e65d0 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (121, 21, NULL, NULL, N'1', N'1', CAST ('1.0000' AS money), 0, 0, NULL, NULL, CAST(0x0000a233011e65d0 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (122, 1, 3, 1, N'Cherry', N'asdasdasd22222222222222222', CAST ('23.0000' AS money), 1221, 12, NULL, 4, CAST(0x0000a2330175f067 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (123, 1, 3, 1, N'Cherry', N'asdasdasd12345', CAST ('23.0000' AS money), 1221, 12, NULL, 4, CAST(0x0000a23301765955 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (124, 1, 3, 1, N'Cherry', N'asdasdasd12345ssssssssss', CAST ('23.0000' AS money), 1221, 12, NULL, 4, CAST(0x0000a23301771355 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (125, 1, 3, 1, N'Cherry', N'asdasdasd12345ssssssssss', CAST ('23.0000' AS money), 1221, 12, NULL, 12, CAST(0x0000a23400f3162c AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (126, 0, NULL, NULL, N'1', N'1', NULL, NULL, NULL, NULL, NULL, CAST(0x0000a23400f322b3 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (127, 22, NULL, NULL, N'1', N'1', CAST ('0.0000' AS money), 0, 0, NULL, NULL, CAST(0x0000a23400f322b3 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (128, 1, 3, 1, N'Cherry', N'asdasdasd12345ssssssssss', CAST ('1.0000' AS money), 1221, 12, NULL, 12, CAST(0x0000a23400d4ee7a AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (129, 5, 1, 3, N'Chocolate', NULL, CAST ('11.0000' AS money), -189, -12, NULL, 3, CAST(0x0000a2340154cd63 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (130, 1, 3, 1, N'Cherry', N'asdasdasd12345ssssssssss', CAST ('1.0000' AS money), 1217, 12, NULL, 12, CAST(0x0000a23600f5b0e8 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (131, 5, 1, 3, N'Chocolate', NULL, CAST ('11.0000' AS money), -193, -12, NULL, 3, CAST(0x0000a23600f5b0ef AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (132, 1, 3, 1, N'Cherry', N'asdasdasd12345ssssssssss', CAST ('1.0000' AS money), 1213, 12, NULL, 12, CAST(0x0000a23600f5dc36 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (133, 5, 1, 3, N'Chocolate', NULL, CAST ('11.0000' AS money), -197, -12, NULL, 3, CAST(0x0000a23600f5dc36 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (134, 1, 3, 1, N'Cherry', N'asdasdasd12345ssssssssss', CAST ('1.0000' AS money), 1209, 12, NULL, 12, CAST(0x0000a23600fc3be3 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (135, 5, 1, 3, N'Chocolate', NULL, CAST ('11.0000' AS money), -201, -12, NULL, 3, CAST(0x0000a23600fc3bec AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (136, 1, 3, 1, N'Cherry', N'asdasdasd12345ssssssssss', CAST ('1.0000' AS money), 1213, 12, NULL, 12, CAST(0x0000a23600fc5646 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (137, 5, 1, 3, N'Chocolate', NULL, CAST ('11.0000' AS money), -197, -12, NULL, 3, CAST(0x0000a23600fc5646 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (138, 1, 3, 1, N'Cherry', N'asdasdasd12345ssssssssss', CAST ('1.0000' AS money), 1219, 12, NULL, 12, CAST(0x0000a23600fc6a32 AS datetime), N'admin')

GO
INSERT INTO [Production].[ProductHistory] ([ProductHistoryId], [ProductId], [UnitMeasureId], [CategoryId], [Name], [Code], [UnitPrice], [UnitsInStock], [UnitsOnOrder], [Store], [ReorderLevel], [ModifiedDate], [ModifiedByUser])
	VALUES (139, 5, 1, 3, N'Chocolate', NULL, CAST ('11.0000' AS money), -193, -12, NULL, 3, CAST(0x0000a23600fc6a32 AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Production].[ProductHistory] OFF
GO

SET IDENTITY_INSERT [Production].[Store] ON
GO
INSERT INTO [Production].[Store] ([StoreId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (1, N'Kitchen', CAST(0x0000a22e00180831 AS datetime), N'admin')

GO
INSERT INTO [Production].[Store] ([StoreId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (2, N'Bar', CAST(0x0000a22e0018168f AS datetime), N'admin')

GO
INSERT INTO [Production].[Store] ([StoreId], [Name], [ModifiedDate], [ModifiedByUser])
	VALUES (3, N'Basement', CAST(0x0000a22e0079067c AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Production].[Store] OFF
GO

SET IDENTITY_INSERT [HumanResources].[Shift] ON
GO
INSERT INTO [HumanResources].[Shift] ([ShiftId], [Name], [StartHour], [EndHour], [ModifiedDate], [ModifiedByUser])
	VALUES (1, N'Day', CAST(0x00008eac0041eb00 AS datetime), CAST(0x00008eac00c5c100 AS datetime), CAST(0x0000a22201662249 AS datetime), N'admin')

GO
INSERT INTO [HumanResources].[Shift] ([ShiftId], [Name], [StartHour], [EndHour], [ModifiedDate], [ModifiedByUser])
	VALUES (2, N'Evening', CAST(0x00008eac00000000 AS datetime), CAST(0x00008eac011826c0 AS datetime), CAST(0x0000a22e00dabe43 AS datetime), N'admin')

GO
INSERT INTO [HumanResources].[Shift] ([ShiftId], [Name], [StartHour], [EndHour], [ModifiedDate], [ModifiedByUser])
	VALUES (3, N'Night', CAST(0x00008eac00f73140 AS datetime), CAST(0x00008eac017b0740 AS datetime), CAST(0x0000a22201650a59 AS datetime), N'admin')

GO
SET IDENTITY_INSERT [HumanResources].[Shift] OFF
GO

SET IDENTITY_INSERT [Purchasing].[PurchaseOrderStatus] ON
GO
INSERT INTO [Purchasing].[PurchaseOrderStatus] ([PurchaseOrderStatusId], [Name], [ModifiedDate], [ModifiedByUser], [IsVisible])
	VALUES (1, N'Pending', CAST(0x0000a22301819b04 AS datetime), N'admin', CAST ('True' AS bit))

GO
INSERT INTO [Purchasing].[PurchaseOrderStatus] ([PurchaseOrderStatusId], [Name], [ModifiedDate], [ModifiedByUser], [IsVisible])
	VALUES (2, N'Approved', CAST(0x0000a2230181a72f AS datetime), N'admin', CAST ('True' AS bit))

GO
INSERT INTO [Purchasing].[PurchaseOrderStatus] ([PurchaseOrderStatusId], [Name], [ModifiedDate], [ModifiedByUser], [IsVisible])
	VALUES (3, N'Rejected', CAST(0x0000a2230181affa AS datetime), N'admin', CAST ('True' AS bit))

GO
INSERT INTO [Purchasing].[PurchaseOrderStatus] ([PurchaseOrderStatusId], [Name], [ModifiedDate], [ModifiedByUser], [IsVisible])
	VALUES (4, N'Complete', CAST(0x0000a2230181b875 AS datetime), N'admin', CAST ('True' AS bit))

GO
SET IDENTITY_INSERT [Purchasing].[PurchaseOrderStatus] OFF
GO

SET IDENTITY_INSERT [Sales].[Customer] ON
GO
INSERT INTO [Sales].[Customer] ([CustomerID], [CompanyName], [ContactName], [Address], [Country], [Phone], [Email], [ModifiedDate], [ModifiedByUser])
	VALUES (1, N'Apple', N'John Doe', N'ad da dsf sdfgsdf ', N'Ireland', N'98 98989 8767 ', N'a@abv.bg', CAST(0x0000a21f00aecabf AS datetime), NULL)

GO
SET IDENTITY_INSERT [Sales].[Customer] OFF
GO

SET IDENTITY_INSERT [Admin].[EmailTemplate] ON
GO
INSERT INTO [Admin].[EmailTemplate] ([EmailTemplateId], [From], [Cc], [Bcc], [Subject], [TextBody], [HtmlBody], [AttachmentName], [IsDefault], [ModifiedDate], [ModifiedByUser])
	VALUES (1, N'ytodorovytodorov.com', N'ytodorov@ytodorov.com', N'ddantodd@abv.bg', N'Purchase Order', N'Here goes the text', N'Here goes the html text', N'PurchaseOrder', CAST ('True' AS bit), CAST(0x0000a23500c2bddc AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Admin].[EmailTemplate] OFF
GO

SET IDENTITY_INSERT [HumanResources].[Employee] ON
GO
INSERT INTO [HumanResources].[Employee] ([EmployeeID], [LastName], [FirstName], [BirthDate], [HireDate], [Address], [City], [Region], [PostalCode], [Country], [HomePhone], [PreviousExperience], [ModifiedDate], [ModifiedByUser])
	VALUES (1, N'Ana', N'Smith', CAST(0x0000a21100000000 AS datetime), CAST(0x0000a24100000000 AS datetime), N'dsf2', N'a1111', N's', N'sds', N's', N'ss', N'asd', CAST(0x0000a22e0100a5ff AS datetime), N'admin')

GO
SET IDENTITY_INSERT [HumanResources].[Employee] OFF
GO

SET IDENTITY_INSERT [Purchasing].[PurchaseOrderDetail] ON
GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (2, 1, 5, 211, CAST ('22.0000' AS money), 200, 100, CAST(0x0000a22d011044f2 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (4, 2, 5, 12, CAST ('3.0000' AS money), 3, 1, CAST(0x0000a22a00a5666c AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (10, 1, 5, 23, CAST ('333.0000' AS money), 3, 100, CAST(0x0000a22d00bd4dce AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (16, 2, 1, 4111, CAST ('10000.0000' AS money), 2, 10011, CAST(0x0000a22a00a56673 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (18, NULL, 5, 2, CAST ('3.0000' AS money), 4, 5, CAST(0x0000a22400dd70db AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (19, NULL, 5, 77, CAST ('777.0000' AS money), 77, 77, CAST(0x0000a22400dd8749 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (20, NULL, 1, 77, CAST ('6.0000' AS money), 5, 4, CAST(0x0000a22400dec95e AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (21, NULL, 1, 4, CAST ('5.0000' AS money), 55, 5, CAST(0x0000a22401112896 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (22, 3, 1, 551, CAST ('555.0000' AS money), 45, 5, CAST(0x0000a22a00d2a48a AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (23, 2, 5, 22, CAST ('22323.0000' AS money), 232323, 5444, CAST(0x0000a22a00a56673 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (25, 4, 1, 33, CAST ('33.0000' AS money), 1, 2, CAST(0x0000a22500e5bc29 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (26, 5, 5, 3, CAST ('2.0000' AS money), 12, 22, CAST(0x0000a22600ab7919 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (28, 2, 1, NULL, CAST ('10000.0000' AS money), NULL, NULL, CAST(0x0000a22a00a56673 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (29, 3, 1, 31, CAST ('10000.0000' AS money), 1, 1, CAST(0x0000a22a00d32059 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (30, 3, 1, 5, CAST ('10000.0000' AS money), 4, NULL, CAST(0x0000a22a00b29be5 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (31, 11, 5, NULL, CAST ('2.0000' AS money), NULL, NULL, CAST(0x0000a22d00a1b712 AS datetime), N'pavlina')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (32, 10, 1, 12, CAST ('1.0000' AS money), 0, 0, CAST(0x0000a22d00a0f51f AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (34, 3, 1, 1, CAST ('2.0000' AS money), NULL, NULL, CAST(0x0000a2340126a015 AS datetime), N'admin')

GO
INSERT INTO [Purchasing].[PurchaseOrderDetail] ([PurchaseOrderDetailId], [PurchaseOrderId], [ProductId], [OrderQuantity], [UnitPrice], [ReceivedQuantity], [ReturnedQuantity], [ModifiedDate], [ModifiedByUser])
	VALUES (35, 3, 1, 1, NULL, NULL, NULL, CAST(0x0000a2340126dad2 AS datetime), N'admin')

GO
SET IDENTITY_INSERT [Purchasing].[PurchaseOrderDetail] OFF
GO

--Indexes of table Purchasing.PurchaseOrderHeader
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Purchasing].[PurchaseOrderHeader] ADD CONSTRAINT [PK_PurchaseOrderHeader_PurchaseOrderID] PRIMARY KEY CLUSTERED ([PurchaseOrderId]) 
GO

--Indexes of table Production.RecipeIngredient
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Production].[RecipeIngredient] ADD CONSTRAINT [PK_RecipeIngredient] PRIMARY KEY CLUSTERED ([RecipeIngredientId]) 
GO

--Indexes of table Production.Recipe
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Production].[Recipe] ADD CONSTRAINT [PK_Recipe] PRIMARY KEY CLUSTERED ([RecipeId]) 
GO

--Indexes of table Production.Product
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Production].[Product] ADD CONSTRAINT [PK_xProduct] PRIMARY KEY CLUSTERED ([ProductId]) 
GO

--Indexes of table Purchasing.ProductVendor
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Purchasing].[ProductVendor] ADD CONSTRAINT [PK_ProductVendor_1] PRIMARY KEY CLUSTERED ([ProductVendorId]) 
GO

--Indexes of table Sales.SalesOrderStatus
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Sales].[SalesOrderStatus] ADD CONSTRAINT [PK_SalesOrderStatus] PRIMARY KEY CLUSTERED ([SalesOrderStatusId]) 
GO

--Indexes of table Sales.SalesOrderHeader
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Sales].[SalesOrderHeader] ADD CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED ([OrderID]) 
GO

--Indexes of table Purchasing.ShipMethod
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Purchasing].[ShipMethod] ADD CONSTRAINT [PK_ShipMethod] PRIMARY KEY CLUSTERED ([ShipMethodId]) 
GO

--Indexes of table Sales.SalesOrderDetail
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Sales].[SalesOrderDetail] ADD CONSTRAINT [PK_OrderDetail] PRIMARY KEY CLUSTERED ([SalesOrderDetailId]) 
GO

--Indexes of table HumanResources.EmployeeDepartment
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [HumanResources].[EmployeeDepartment] ADD CONSTRAINT [PK_EmployeeDepartment] PRIMARY KEY CLUSTERED ([EmployeeDepartmentId]) 
GO

--Indexes of table HumanResources.Department
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [HumanResources].[Department] ADD CONSTRAINT [PK_Department] PRIMARY KEY CLUSTERED ([DepartmentId]) 
GO

--Indexes of table Production.UnitMeasure
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Production].[UnitMeasure] ADD CONSTRAINT [PK_xUnit] PRIMARY KEY CLUSTERED ([UnitMeasureId]) 
GO

--Indexes of table Production.ProductCategory
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Production].[ProductCategory] ADD CONSTRAINT [PK_xCategory] PRIMARY KEY CLUSTERED ([CategoryId]) 
GO

--Indexes of table Purchasing.Vendor
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Purchasing].[Vendor] ADD CONSTRAINT [PK_xSupplier] PRIMARY KEY CLUSTERED ([VendorId]) 
GO

--Indexes of table Production.ProductHistory
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Production].[ProductHistory] ADD CONSTRAINT [PK_ProductHistory_1] PRIMARY KEY CLUSTERED ([ProductHistoryId]) 
GO

--Indexes of table Production.Store
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Production].[Store] ADD CONSTRAINT [PK_Store] PRIMARY KEY CLUSTERED ([StoreId]) 
GO

--Indexes of table HumanResources.Shift
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [HumanResources].[Shift] ADD CONSTRAINT [PK_Shift] PRIMARY KEY CLUSTERED ([ShiftId]) 
GO

--Indexes of table Purchasing.PurchaseOrderStatus
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Purchasing].[PurchaseOrderStatus] ADD CONSTRAINT [PK_PurchaseOrderStatus] PRIMARY KEY CLUSTERED ([PurchaseOrderStatusId]) 
GO

--Indexes of table Sales.Customer
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Sales].[Customer] ADD CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED ([CustomerID]) 
GO

--Indexes of table Admin.EmailTemplate
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Admin].[EmailTemplate] ADD CONSTRAINT [PK_EmailTemplate] PRIMARY KEY CLUSTERED ([EmailTemplateId]) 
GO

--Indexes of table HumanResources.Employee
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [HumanResources].[Employee] ADD CONSTRAINT [PK_Employees] PRIMARY KEY CLUSTERED ([EmployeeID]) 
GO

--Indexes of table Purchasing.PurchaseOrderDetail
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE [Purchasing].[PurchaseOrderDetail] ADD CONSTRAINT [PK_PurchaseOrderDetail] PRIMARY KEY CLUSTERED ([PurchaseOrderDetailId]) 
GO

--Foreign Keys

USE [db804b3a50697f4e00b7cca1e6015cf402]
GO
ALTER TABLE [HumanResources].[EmployeeDepartment] WITH CHECK ADD CONSTRAINT [FK_EmployeeDepartment_Department] 
	FOREIGN KEY ([DepartmentId]) REFERENCES [HumanResources].[Department] ([DepartmentId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [HumanResources].[EmployeeDepartment] CHECK CONSTRAINT [FK_EmployeeDepartment_Department]
GO
ALTER TABLE [HumanResources].[EmployeeDepartment] WITH CHECK ADD CONSTRAINT [FK_EmployeeDepartment_Employee] 
	FOREIGN KEY ([EmployeeId]) REFERENCES [HumanResources].[Employee] ([EmployeeID])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [HumanResources].[EmployeeDepartment] CHECK CONSTRAINT [FK_EmployeeDepartment_Employee]
GO
ALTER TABLE [HumanResources].[EmployeeDepartment] WITH CHECK ADD CONSTRAINT [FK_EmployeeDepartment_Shift] 
	FOREIGN KEY ([ShiftId]) REFERENCES [HumanResources].[Shift] ([ShiftId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [HumanResources].[EmployeeDepartment] CHECK CONSTRAINT [FK_EmployeeDepartment_Shift]
GO
ALTER TABLE [Production].[Product] WITH CHECK ADD CONSTRAINT [FK_xProduct_xCategory] 
	FOREIGN KEY ([CategoryId]) REFERENCES [Production].[ProductCategory] ([CategoryId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Production].[Product] CHECK CONSTRAINT [FK_xProduct_xCategory]
GO
ALTER TABLE [Production].[Product] WITH CHECK ADD CONSTRAINT [FK_Product_Store] 
	FOREIGN KEY ([StoreId]) REFERENCES [Production].[Store] ([StoreId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Production].[Product] CHECK CONSTRAINT [FK_Product_Store]
GO
ALTER TABLE [Production].[Product] WITH CHECK ADD CONSTRAINT [FK_xProduct_xUnit] 
	FOREIGN KEY ([UnitMeasureId]) REFERENCES [Production].[UnitMeasure] ([UnitMeasureId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Production].[Product] CHECK CONSTRAINT [FK_xProduct_xUnit]
GO
ALTER TABLE [Purchasing].[ProductVendor] WITH CHECK ADD CONSTRAINT [FK_ProductVendor_Product1] 
	FOREIGN KEY ([ProductId]) REFERENCES [Production].[Product] ([ProductId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Purchasing].[ProductVendor] CHECK CONSTRAINT [FK_ProductVendor_Product1]
GO
ALTER TABLE [Purchasing].[ProductVendor] WITH CHECK ADD CONSTRAINT [FK_ProductVendor_UnitMeasure] 
	FOREIGN KEY ([UnitMeasureId]) REFERENCES [Production].[UnitMeasure] ([UnitMeasureId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Purchasing].[ProductVendor] CHECK CONSTRAINT [FK_ProductVendor_UnitMeasure]
GO
ALTER TABLE [Purchasing].[ProductVendor] WITH CHECK ADD CONSTRAINT [FK_ProductVendor_Vendor] 
	FOREIGN KEY ([VendorId]) REFERENCES [Purchasing].[Vendor] ([VendorId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Purchasing].[ProductVendor] CHECK CONSTRAINT [FK_ProductVendor_Vendor]
GO
ALTER TABLE [Purchasing].[PurchaseOrderDetail] WITH CHECK ADD CONSTRAINT [FK_PurchaseOrderDetail_Product] 
	FOREIGN KEY ([ProductId]) REFERENCES [Production].[Product] ([ProductId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Purchasing].[PurchaseOrderDetail] CHECK CONSTRAINT [FK_PurchaseOrderDetail_Product]
GO
ALTER TABLE [Purchasing].[PurchaseOrderDetail] WITH CHECK ADD CONSTRAINT [FK_PurchaseOrderDetail_PurchaseOrderHeader] 
	FOREIGN KEY ([PurchaseOrderId]) REFERENCES [Purchasing].[PurchaseOrderHeader] ([PurchaseOrderId])
	ON UPDATE NO ACTION
	ON DELETE CASCADE
GO
ALTER TABLE [Purchasing].[PurchaseOrderDetail] CHECK CONSTRAINT [FK_PurchaseOrderDetail_PurchaseOrderHeader]
GO
ALTER TABLE [Purchasing].[PurchaseOrderHeader] WITH CHECK ADD CONSTRAINT [FK_PurchaseOrderHeader_Employee] 
	FOREIGN KEY ([EmployeeId]) REFERENCES [HumanResources].[Employee] ([EmployeeID])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Purchasing].[PurchaseOrderHeader] CHECK CONSTRAINT [FK_PurchaseOrderHeader_Employee]
GO
ALTER TABLE [Purchasing].[PurchaseOrderHeader] WITH CHECK ADD CONSTRAINT [FK_PurchaseOrderHeader_PurchaseOrderStatus] 
	FOREIGN KEY ([StatusId]) REFERENCES [Purchasing].[PurchaseOrderStatus] ([PurchaseOrderStatusId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Purchasing].[PurchaseOrderHeader] CHECK CONSTRAINT [FK_PurchaseOrderHeader_PurchaseOrderStatus]
GO
ALTER TABLE [Purchasing].[PurchaseOrderHeader] WITH CHECK ADD CONSTRAINT [FK_PurchaseOrderHeader_ShipMethod] 
	FOREIGN KEY ([ShipMethodId]) REFERENCES [Purchasing].[ShipMethod] ([ShipMethodId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Purchasing].[PurchaseOrderHeader] CHECK CONSTRAINT [FK_PurchaseOrderHeader_ShipMethod]
GO
ALTER TABLE [Purchasing].[PurchaseOrderHeader] WITH CHECK ADD CONSTRAINT [FK_PurchaseOrderHeader_Vendor] 
	FOREIGN KEY ([VendorId]) REFERENCES [Purchasing].[Vendor] ([VendorId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Purchasing].[PurchaseOrderHeader] CHECK CONSTRAINT [FK_PurchaseOrderHeader_Vendor]
GO
ALTER TABLE [Production].[Recipe] WITH CHECK ADD CONSTRAINT [FK_Recipe_ProductCategory] 
	FOREIGN KEY ([CategoryId]) REFERENCES [Production].[ProductCategory] ([CategoryId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Production].[Recipe] CHECK CONSTRAINT [FK_Recipe_ProductCategory]
GO
ALTER TABLE [Production].[RecipeIngredient] WITH CHECK ADD CONSTRAINT [FK_RecipeIngredient_Product] 
	FOREIGN KEY ([ProductId]) REFERENCES [Production].[Product] ([ProductId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Production].[RecipeIngredient] CHECK CONSTRAINT [FK_RecipeIngredient_Product]
GO
ALTER TABLE [Production].[RecipeIngredient] WITH CHECK ADD CONSTRAINT [FK_RecipeIngredient_Recipe] 
	FOREIGN KEY ([RecipeId]) REFERENCES [Production].[Recipe] ([RecipeId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Production].[RecipeIngredient] CHECK CONSTRAINT [FK_RecipeIngredient_Recipe]
GO
ALTER TABLE [Sales].[SalesOrderDetail] WITH CHECK ADD CONSTRAINT [FK_OrderDetail_Recipe] 
	FOREIGN KEY ([RecipeId]) REFERENCES [Production].[Recipe] ([RecipeId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Sales].[SalesOrderDetail] CHECK CONSTRAINT [FK_OrderDetail_Recipe]
GO
ALTER TABLE [Sales].[SalesOrderDetail] WITH CHECK ADD CONSTRAINT [FK_OrderDetail_Order] 
	FOREIGN KEY ([SalesOrderId]) REFERENCES [Sales].[SalesOrderHeader] ([OrderID])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Sales].[SalesOrderDetail] CHECK CONSTRAINT [FK_OrderDetail_Order]
GO
ALTER TABLE [Sales].[SalesOrderHeader] WITH CHECK ADD CONSTRAINT [FK_Order_Customer] 
	FOREIGN KEY ([CustomerID]) REFERENCES [Sales].[Customer] ([CustomerID])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Sales].[SalesOrderHeader] CHECK CONSTRAINT [FK_Order_Customer]
GO
ALTER TABLE [Sales].[SalesOrderHeader] WITH CHECK ADD CONSTRAINT [FK_Order_Employee] 
	FOREIGN KEY ([EmployeeID]) REFERENCES [HumanResources].[Employee] ([EmployeeID])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Sales].[SalesOrderHeader] CHECK CONSTRAINT [FK_Order_Employee]
GO
ALTER TABLE [Sales].[SalesOrderHeader] WITH CHECK ADD CONSTRAINT [FK_SalesOrderHeader_SalesOrderStatus] 
	FOREIGN KEY ([StatusId]) REFERENCES [Sales].[SalesOrderStatus] ([SalesOrderStatusId])
	ON UPDATE NO ACTION
	ON DELETE SET NULL
GO
ALTER TABLE [Sales].[SalesOrderHeader] CHECK CONSTRAINT [FK_SalesOrderHeader_SalesOrderStatus]
GO

--Computed Columns

USE [db804b3a50697f4e00b7cca1e6015cf402]
GO
ALTER TABLE [Purchasing].[PurchaseOrderHeader] DROP COLUMN [TotalDue]
GO
ALTER TABLE [Purchasing].[PurchaseOrderHeader] ADD [TotalDue] AS (isnull(([SubTotal]+[VAT])+[Freight],(0)))  PERSISTED
GO
ALTER TABLE [Sales].[SalesOrderDetail] DROP COLUMN [LineTotal]
GO
ALTER TABLE [Sales].[SalesOrderDetail] ADD [LineTotal] AS (isnull(([UnitPrice]*((1.0)-isnull([UnitPriceDiscount],(0.0))))*[OrderQuantity],(0.0))) 
GO
ALTER TABLE [Purchasing].[PurchaseOrderDetail] DROP COLUMN [LineTotal]
GO
ALTER TABLE [Purchasing].[PurchaseOrderDetail] ADD [LineTotal] AS (isnull([OrderQuantity]*[UnitPrice],(0.00))) 
GO
ALTER TABLE [Purchasing].[PurchaseOrderDetail] DROP COLUMN [StockedQuantity]
GO
ALTER TABLE [Purchasing].[PurchaseOrderDetail] ADD [StockedQuantity] AS (isnull([ReceivedQuantity]-[ReturnedQuantity],(0.00))) 
GO
